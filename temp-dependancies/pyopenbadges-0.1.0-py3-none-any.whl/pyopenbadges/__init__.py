"""
PyOpenBadges - Une librairie Python moderne pour la création, la validation et la gestion des badges numériques
conformes à la spécification OpenBadge v3.0 de l'IMS Global.
"""

__version__ = "0.1.0"
